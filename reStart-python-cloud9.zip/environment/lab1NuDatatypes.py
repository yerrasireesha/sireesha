"""
Editing a Python file
"""
print("Python has three numeric types: int, float, and complex")
"""
Creating a variable
"""
myvalue=1
print(myvalue)
"""
To get the data type of the variable, use the type() built-in function:
"""
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=3.14
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=True
print(myvalue)
print(type(myvalue))
print(str(myvalue) + "is of the data type" + str(type(myvalue)))